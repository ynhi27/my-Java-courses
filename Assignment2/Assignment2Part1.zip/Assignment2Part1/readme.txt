Student name: Y Nhi Tran
Class and Section: CIS 36A - 13Z
Assignment 2 - Part 2
Due Date: Mon Feb 6, 2023 11:59pm
Date Submitted: 02/04/2023

<Part 1>
Personal Information Class

This program will ask user enter the information of 3 people.
Then it shows those information again in the screen, including name, address, age, and phone number in the format (xxx) xxx-xxxx.
The program also show some error messages when user enter non-numeric age or negative age and not-10-digit phone number.


