Student name: Y Nhi Tran
Class and Section: CIS 36A - 13Z
Assignment 2 - Part 2
Due Date: Mon Feb 6, 2023 11:59pm
Date Submitted: 04/02/2023

<Part 2>
Coin Toss Simulator

This program will run automatically when you click Run button.
It will show the 20 times of flipping coin.
Then print the total times showing head or tail.


