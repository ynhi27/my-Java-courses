/*
Student name: Y Nhi Tran
Class and Section: CIS 36A - 13Z
Assignment 2 - Part 2
Due Date: Mon Feb 6, 2023 11:59pm
Date Submitted: 02/04/2023
*/

package Part2;

public class Driver {

	public static void main(String[] args) {
		Coin c = new Coin();
		c.toss();
	}

}
